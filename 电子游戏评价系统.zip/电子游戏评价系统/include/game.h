#include "diymysql.h"
using namespace std;

typedef struct Info
{
	string intro, age, policy; //��Ϸ���ܣ� ����ּ��� �������� 
}Info;

typedef struct Pow //Ȩ�� 
{
	double gp; //�淨
	double mc; //����
	double art; //����
	double plot; //���� 
	double opt; //��Ӫ 
}Pow;

//typedef struct UnitMedia
//{
//	string name; //ý������
//	double sc; //ý������ 
//}UnitMedia;

//typedef struct Player
//{
//	string name; //������� 
//	double sc; //������� 
//}Player;

//typedef struct Meida
//{
//	UnitMedia plat; //��ƽ̨ 
//	UnitMedia others[10];
//}Media;

typedef struct Score
{
	//Player player; //������� 
	//Media media; //ý������ 
	double avg_player;
	double avg_media;
	double other_media;
	double gp;
	double mc;
	double art;
	double plot;
	double opt;
}Score;

//typedef struct Eva
//{
//	string mediaEva; //ý������ 
//	Score score; //��Ϸ���� 
//}Eva; //���� 

class Game
{
	public:		 
		string GetName() {
			return name;
		}
		
		void UpdateName(string name) {
			this->name = name;
		}
		
		string GetGenre() {
			return genre;
		}
		
		void UpdateGenre(string genre) {
			this->genre = genre;
		}
		
		string GetTag() {
			return tag;
		}
		
		void UpdateTag(string tag) {
			this->tag = tag;
		}
		
		double GetAvgPlayer() {
			return score.avg_player;
		}
		
		void UpdateAvgPlayer(double avg_player) {
			score.avg_player = avg_player;
		}
		
		double GetAvgMedia() {
			return score.avg_media;
		}
		
		void UpdateAvgMedia(double avg_media) {
			score.avg_media = avg_media;
		}
		
		double GetGp() {
			return score.gp;
		}
		
		double GetMc() {
			return score.mc;
		}
		
		double GetArt() {
			return score.art;
		}
		
		double GetPlot() {
			return score.plot;
		}
		
		double GetOpt() {
			return score.opt;
		}
		
		void UpdateGp(double gp) {
			score.gp = gp;
		}
		
		void UpdateMc(double mc) {
			score.mc = mc;
		}
		
		void UpdateArt(double art) {
			score.art = art;
		}
		
		void UpdatePlot(double plot) {
			score.plot = plot;
		}
		
		void UpdateOpt(double opt) {
			score.opt = opt;
		}
		
		string GetAge() {
			return info.age;
		}
		
		string GetPolicy() {
			return info.policy;
		}
		
		string GetIntro() {
			return info.intro;
		}
		
		void UpdateAge(string age) {
			info.age = age;
		}
		
		void UpdatePolicy(string policy) {
			info.policy = policy;
		}
		
		void UpdateIntro(string intro) {
			info.intro = intro;
		}
		
		double GetOtherMedia() {
			return score.other_media;
		}
		
		void UpdateOtherMedia(double other_media) {
			score.other_media = other_media;
		}
		
		double GetPowGp() {
			return pow.gp;
		}
		
		double GetPowMc() {
			return pow.mc;
		}
		
		double GetPowArt() {
			return pow.art;
		}
		
		double GetPowPlot() {
			return pow.plot;
		}
		
		double GetPowOpt() {
			return pow.opt;
		}
		
		void UpdatePowGp(double gp) {
			pow.gp = gp;
		}
		
		void UpdatePowMc(double mc) {
			pow.mc = mc;
		}
		
		void UpdatePowArt(double art) {
			pow.art = art;
		}
		
		void UpdatePowPlot(double plot) {
			pow.plot = plot;
		}
		
		void UpdatePowOpt(double opt) {
			pow.opt = opt;
		}
		
		
		
		void PrintRatePow() {
			printf("�淨��%.2lf\n���֣�%.2lf\n������%.2lf\n���飺%.2lf\n��Ӫ��%.2lf\n", pow.gp, pow.mc, pow.art, pow.plot, pow.opt);
		}
		
		void SetPow(double gp, double mc, double art, double plot, double opt) {
			pow.gp = gp;
			pow.mc = mc;
			pow.art = art;
			pow.plot = plot;
			pow.opt = opt;
		}
		
	private:
		Pow pow; //����Ȩ�� 
		string name;  //��Ϸ���� 
		Info info;  //��Ϸ��� 
		string genre; //��Ϸ����
		string tag; //��Ϸ��ǩ 
		Score score;
};
