#include "include\module.h"
using namespace std;

int main() 
{		   
	Begin(); 
	return 0;
}


 
