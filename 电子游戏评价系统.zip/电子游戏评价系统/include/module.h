#include "game.h"
#define eps 1e-8 
using namespace std; 
const int PORT = 3308;
const char* HOST = "localhost";
const char* USERNAME = "root";
const char* PASSWORD = "123456";
const char* DATABASE = "game";
void BeginUI();
void ViHomepageUI();
void ViHomepage();
void ViLogin();
void MaHomepageUI();
void MaHomepage();
void MaLogin();
void SignUI();
void Sign();
void Begin();
void Search();
void SearchUI();
void Search1();
void BrowsUI1();
void BrowsUI2();
void Brows1();
void Brows2();
void BrowsUI();
void Brows();
void MaControl();
void MaControl1();
void MaControl2();
void MaControl3();
void MaControlUI();
void MaControlUI1();
void MaControlUI2();
void MaControlUI3();
int FindNum(string num);
void SetCursor(int x, int y);
bool isInt(const char* str);
bool isFloat(const char * str);
bool FindDirectory(string genre);
void ScoreUI();
void ScoreOp();
void AddGameDirectory();
void DeleteGameDirectory();
void UpdateGameDirectory();

typedef struct DT
{
	list<DT*> SDT;
	DT* fa;
	string genre;
}DT;

typedef struct Node
{
	string genre;
	int left;
	int right;
}Node;

BOOL WINAPI SetConsoleCursorPosition
(
	HANDLE hConsoleOutput, //��׼������
	COORD  dwCursorPosition //Ҫ���õ�λ����Ϣ
);

void SetCursor(int x, int y) //���ƺڴ��ڹ�� 
{
	HANDLE hOutput = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD coo;
	coo.X = x;
	coo.Y = y;
	SetConsoleCursorPosition(hOutput, coo);
}

//�ж��ַ����Ƿ�Ϊ���������жϸ�ʽ�������Ƿ�Χ��
bool isInt(const char* str)
{
	bool isNum = false;

	int index = 0;
	for (; *str != '\0'; str++, index++)
	{
		switch (*str)
		{
		case '0':case'1':case'2':case'3':case'4':case'5':
		case'6':case'7':case'8':case'9':
			isNum = true;
			break;
		case '-':case '+':
			if (index != 0)
			{
				return false;
			}
			break;
		default:
			return false;
		}
	}

	if (!isNum)
	{
		return false;
	}

	return true;
}

int FindNum(string num)
{
	for(int i = 1 ; i <= 100 ; i++) if(num == to_string(i)) return i;
	return -1;
}

//�ж��ַ����Ƿ�Ϊ�����������жϸ�ʽ�������Ƿ�Χ��
bool isFloat(const char * str)
{
	bool isE = false,
		isPoint = false,
		numBefore = false,
		numBehind = false;

	int index = 0;
	for (; *str != '\0'; str++, index++)
	{
		switch (*str)
		{
		case '0':case'1':case'2':case'3':case'4':case'5':
		case'6':case'7':case'8':case'9':
			if (isE)
			{
				numBehind = true;
			}
			else
			{
				numBefore = true;
			}
			break;
		case '+':case '-':
			if (index != 0)
			{
				return false;
			}
			break;
		case 'e':case 'E':
			if (isE || !numBefore)
			{
				return false;
			}
			else
			{
				isPoint = true;
				index = -1;
				isE = true;
			}
			break;
		case '.':
			if (isPoint)
			{
				return false;
			}
			else
			{
				isPoint = true;
			}
			break;
		default:
			return false;
		}
	}

	if (!numBefore)
	{
		return false;
	}
	else if (isE && !numBehind)
	{
		return false;
	}

	return true;
}


//���ݿ����ģ�� 
class Database
{
	public:
		void Connect(const char* HOST, const char* USERNAME, const char* PASSWORD, const char* DATABASE, const int PORT);
		
		void GetTableField(const char* tb_name);
		
		void QueryTable(const char* tb_name);
		
		void Implement(const char* sentence);
		
		void InputGame(const char* tb_name);
		
		void ConvertGame(Game* gs, int* num);
		
		void InputDirectory(const char* tb_name);
		
		void ConvertDirectory(Node* nodes, int* num);
		
		void OutputUser(const char* tb_name, string user, string password);
		
		bool QueryUser(const char* tb_name, const char* user, const char* password);
		
		bool QueryScore(const char* tb_name, const char* user, const char* name);
		
		void AddScore(const char* tb_name, const char* user, const char* name, double gp, double mc, double art, double plot, double opt);
		
		void UpdateScore(const char* tb_name, const char* user, const char* name, double gp, double mc, double art, double plot, double opt);
		
		double AvgRate(const char* tb_name, const char* field_name, const char* name);
		
		void PrintRate(const char* tb_name, const char* user, const char* name);
		
		void GetScore(const char* tb_name, const char* user, const char* name, double* gp, double* mc, double* art, double* plot, double* opt);
		
		Database() 
		{ 
			db = new DataBase;
			state = false; 
			game_num = directory_num = 0;
		}
	
	private:
		DataBase* db;
		int game_num;
		int directory_num;
		bool state;
		char sentence[10000];
		string words[100000];
		Game gameset[100];
		Node nodes[100];
		
};

void Database::PrintRate(const char* tb_name, const char* user, const char* name)
{
	db->PrintRate(tb_name, user, name);
}

void Database::Connect(const char* HOST, const char* USERNAME, const char* PASSWORD, const char* DATABASE, const int PORT)
{
	if(db->Connect(HOST, USERNAME, PASSWORD, DATABASE, PORT)) state = true; //�������ݿ� 
}

void Database::GetTableField(const char* tb_name)
{
	db->GetTableField(tb_name);
}

void Database::QueryTable(const char* tb_name)
{
	db->Query(tb_name);
}

void Database::Implement(const char* sentence)
{
	db->Implement(sentence);
}

bool Database::QueryUser(const char* tb_name, const char* user, const char* password)
{
	if(db->QueryUser(tb_name, user, password)) return true;
	return false;
}

void Database::GetScore(const char* tb_name, const char* user, const char* name, double* gp, double* mc, double* art, double* plot, double* opt)
{
	db->GetScore(tb_name, user, name, gp, mc, art, plot, opt);
}

bool Database::QueryScore(const char* tb_name, const char* user, const char* name)
{
	if(db->QueryScore(tb_name, user, name)) return true;
	return false;	
}

void Database::AddScore(const char* tb_name, const char* user, const char* name, double gp, double mc, double art, double plot, double opt)
{
	sprintf(sentence, "insert into %s values ('%s', '%s', %.2f, %.2f, %.2f, %.2f, %.2f);", tb_name, user, name, gp, mc, art, plot, opt);
	db->Implement(sentence);
}

void Database::UpdateScore(const char* tb_name, const char* user, const char* name, double gp, double mc, double art, double plot, double opt)
{
	sprintf(sentence, "update %s set user = '%s', ��Ϸ���� = '%s', �淨 = %.2f, ���� = %.2f, ���� = %.2f, ���� = %.2f, ��Ӫ = %.2f;", tb_name, user, name, gp, mc, art, plot, opt);
	db->Implement(sentence);
}

double Database::AvgRate(const char* tb_name, const char* field_name, const char* name)
{
	return db->GetAvgRate(tb_name, field_name, name);
}

void Database::InputGame(const char* tb_name) //�������� 
{
	char* s[10000];
	char* ss;
	int row;
	int col;
	db->GetInformation(tb_name, s, &row, &col);
	int k = -1;
	game_num = row;
	for(int i = 0 ; i < row ; i++)
	{
		for(int j = 0 ; j < col ; j++)
		{
			ss = s[++k];
			switch(j % col)
			{
				case 0:
					gameset[i].UpdateName(ss); break;
				case 1:
					gameset[i].UpdateGenre(ss); break;
				case 2:
					gameset[i].UpdateTag(ss); break;
				case 3:
					gameset[i].UpdateAvgPlayer(strtod(ss, NULL)); break;
				case 4:
					gameset[i].UpdateAvgMedia(strtod(ss, NULL)); break;
				case 5:
					gameset[i].UpdateGp(strtod(ss, NULL)); break;
				case 6:
					gameset[i].UpdatePowGp(strtod(ss, NULL)); break;
				case 7:
					gameset[i].UpdateMc(strtod(ss, NULL)); break;
				case 8:
					gameset[i].UpdatePowMc(strtod(ss, NULL)); break;
				case 9:
					gameset[i].UpdateArt(strtod(ss, NULL)); break;
				case 10:
					gameset[i].UpdatePowArt(strtod(ss, NULL)); break;
				case 11:
					gameset[i].UpdatePlot(strtod(ss, NULL)); break;
				case 12:
					gameset[i].UpdatePowPlot(strtod(ss, NULL)); break;
				case 13:
					gameset[i].UpdateOpt(strtod(ss, NULL)); break;
				case 14:
					gameset[i].UpdatePowOpt(strtod(ss, NULL)); break;
				case 15:
					gameset[i].UpdateOtherMedia(strtod(ss, NULL)); break;
				case 16:
					gameset[i].UpdateIntro(ss); break;
				case 17:
					gameset[i].UpdateAge(ss); break;
				case 18:
					gameset[i].UpdatePolicy(ss); break;
			}
		}
	}
}

void Database::InputDirectory(const char* tb_name)
{
	char* s[10000];
	char *ss;
	int row = 0;
	int col = 0;
	db->GetInformation(tb_name, s, &row, &col);
	int k = -1;
	directory_num = row;
	for(int i = 0 ; i < row ; i++)
	{
		for(int j = 0 ; j < col ; j++)
		{
			ss = s[++k];
			if(j == 0)
				nodes[i].genre = ss;
			else if(j == 1)
				nodes[i].left = atoi(ss); 
			else if(j == 2)
				nodes[i].right = atoi(ss);
		}
	}
	return ;
}

void Database::ConvertGame(Game* gs, int* num)
{
	for(int i = 0 ; i < game_num ; i++) gs[i] = gameset[i];
	*num = game_num;	
}

void Database::ConvertDirectory(Node* node, int* num)
{
	for(int i = 0 ; i < directory_num ; i++) node[i] = nodes[i];
	*num = directory_num;
}

void Database::OutputUser(const char* tb_name, string user, string password)
{
	sprintf(sentence, "insert into %s values ('%s', '%s');", tb_name, user.data(), password.data());
	db->Implement(sentence);
}


//��Ϸȫ��ģ��
class GameSet
{
	public:
		Game* GetGame(string name); //��ȡ��Ϸ���ƶ�Ӧ����Ϸ��Ϣ 
		
		bool PrintGameByName(string name); //������Ϸ���ƴ�ӡ��Ϸ��Ϣ 
		
		bool PrintGameByAge(int age); //������Ϸ����ּ���ӡ��Ϸ��Ϣ 
		
		bool PrintGameByGenre(string genre); //������Ϸ���ʹ�ӡ��Ϸ��Ϣ 
		
		void InputGame(const char* tb_name); //������Ϸ��Ϣ 
		
		void ShowGame(); //չʾ������Ϸ��Ϣ 
		
		void OutputGame(const char* tb_name); //������Ϸ��Ϣ
		
		bool UpdateGame(string name); //������Ϸ��Ϣ 
					
		bool AddGame(); //������Ϸ��Ϣ 
		
		bool DeleteGame(string name); //ɾ����Ϸ��Ϣ 
		
		void PrintGameName(); //��ӡ���е���Ϸ���� 
		
		bool UpdateGamePow(string name); //������Ϸ����Ȩ�� 
		
		bool DeleteGamePow(string name); //ɾ����Ϸ����Ȩ�� 
		
		bool FindGameName(string name); //������Ϸ���� 
		
		bool ShowGamePow(string name); //չʾ��Ϸ����Ȩ�� 
		
		void UpdateGameRate(const char* tb_name, const char* field_name, string name);
		
		void AvgPlayer(string name);
		
		void AllAvgPlayer();
		
		GameSet(Database* Db) {
			db = Db;
			num = 0;
			top = 100;
		}
		
	private:
		Database* db;
		int num;
		int top;
		char sentence[1000];
		Game gameset[100];
		list<Game> GS;
};

void GameSet::AllAvgPlayer()
{
	list<Game>::iterator it = GS.begin();
	Game* g = &(*it);
	double rate;
	while(it != GS.end())
	{
		rate = g->GetGp() * g->GetPowGp() + g->GetMc() * g->GetPowMc() + g->GetArt() * g->GetPowArt() + g->GetPlot() * g->GetPowPlot() + g->GetOpt() * g->GetPowOpt();
		g->UpdateAvgPlayer(rate);
		it++;
		g = &(*it);
	}	
}

void GameSet::AvgPlayer(string name)
{
	list<Game>::iterator it = GS.begin();
	Game* g = &(*it);
	double rate;
	while(it != GS.end())
	{
		if(g->GetName() == name)
		{
			rate = g->GetGp() * g->GetPowGp() + g->GetMc() * g->GetPowMc() + g->GetArt() * g->GetPowArt() + g->GetPlot() * g->GetPowPlot() + g->GetOpt() * g->GetPowOpt();
			g->UpdateAvgPlayer(rate);
			return ;
		}
		it++;
		g = &(*it);
	}
}

void GameSet::UpdateGameRate(const char* tb_name, const char* field_name, string name)
{
	list<Game>::iterator it = GS.begin();
	Game* g = &(*it);
	double rate;
	while(it != GS.end())
	{
		if(g->GetName() == name)
		{
			rate = db->AvgRate(tb_name, field_name, name.data());
			if(field_name == "�淨") g->UpdateGp(rate);
			else if(field_name == "����") g->UpdateMc(rate);
			else if(field_name == "����") g->UpdateArt(rate);
			else if(field_name == "����") g->UpdatePlot(rate);
			else if(field_name == "��Ӫ") g->UpdateOpt(rate);
			return ;
		}
		it++;
		g = &(*it);
	}
}

bool GameSet::FindGameName(string name)
{
	list<Game>::iterator it = GS.begin();
	Game* g = &(*it);
	while(it != GS.end())
	{
		if(g->GetName() == name) return true;
		it++;
		g = &(*it);
	}
	return false;
}

bool GameSet::ShowGamePow(string name)
{
	list<Game>::iterator it = GS.begin();
	Game* g = &(*it);
	while(it != GS.end())
	{
		if(g->GetName() == name) break;
		it++;
		g = &(*it);
	}
	if(it == GS.end()) return false;
	else
	{
		cout << "------------------------\n";
		g->PrintRatePow();
		return true;
	}	
}

bool GameSet::DeleteGamePow(string name)
{
	if(num == 0)
	{
//		cout << "��Ϸ�������\n";
		return false;
	}
	
	list<Game>::iterator it = GS.begin();
	while(it != GS.end())
	{
		if((*it).GetName() == name) 
		{
			(*it).SetPow(0, 0, 0, 0, 0);
			cout << "ɾ���ɹ���\n"; 
			return true;
		}
		it++;
	}
//	cout << "�Ҳ�����Ҫɾ������Ϸ��\n";
	return false;
}

bool GameSet::UpdateGamePow(string name)
{
	list<Game>::iterator it = GS.begin();
	Game* g = &(*it);
	while(it != GS.end())
	{
		if(g->GetName() == name) break;
		it++;
		g = &(*it);
	}
	if(it == GS.end()) return false;
	else
	{
		cin.sync();
		cout << "------------------------\n";
		double sc;
		double gp, mc, art, plot, opt;
		string s;
		do
		{
			cout << "�������淨Ȩ�أ�0~1֮�䣩��";
			getline(cin, s);
			if(isFloat(s.c_str()))
			{
				gp = strtod(s.c_str(), NULL);
				if(gp >= 0  && gp <= 1)
				{	
					break;			
				}
				else 
				{
					cout << "��Ч���룡\n";
				}
			}
			else
			{
				cout << "��Ч���룡\n";
			}
		}while(1);
			
		do
		{
			cout << "����������Ȩ�أ�0~1֮�䣩��";
			getline(cin, s);
			if(isFloat(s.c_str()))
			{
				mc = strtod(s.c_str(), NULL);
				if(0 <= mc && mc <= 1)
				{
					break;
				}
				else
				{
					cout << "��Ч���룡\n";
				}
			}
			else
			{
				cout << "��Ч���룡\n";
			}
			
			
		}while(1);

		do
		{
			cout << "����������Ȩ�أ�0~1֮�䣩��";
			getline(cin, s);
			if(isFloat(s.c_str()))
			{
				art = strtod(s.c_str(), NULL);
				if(0 <= art && art <= 1)
				{
					break;
				}
				else
				{
					cout << "��Ч���룡\n";
				}
			}
			else
			{
				cout << "��Ч���룡\n";
			}
		}while(1);
		
		
		do
		{
			cout << "���������Ȩ�أ�0~1֮�䣩��";
			getline(cin, s);
			if(isFloat(s.c_str()))
			{
				plot = strtod(s.c_str(), NULL);
				if(0 <= plot && plot <= 1)
				{
					break;
				}
				else
				{
					cout << "��Ч���룡\n";
				}
			}
			else
			{
				cout << "��Ч���룡\n";
			}			
		}while(1);

		do
		{
			cout << "��������ӪȨ�أ�0~1֮�䣩��";
			getline(cin, s);
			if(isFloat(s.c_str()))
			{
				opt = strtod(s.c_str(), NULL);
				if(0 <= opt && opt <= 1)
				{
					break;
				}
				else
				{
					cout << "��Ч���룡\n";
				}
			}
			else
			{
				cout << "��Ч���룡\n";
			}			
		}while(1);	
			
		if(fabs(gp + mc + art + plot + opt - 1) < eps)
		{
			g->SetPow(gp, mc, art, plot, opt);
			g->PrintRatePow();
			cout << "���óɹ���\n";
			return true;
		}
		else
		{
			cout << "����Ȩ�غͲ�Ϊ1������ʧ�ܣ�\n";
			return false;
		}
	}
}


void GameSet::PrintGameName()
{
	system("cls");
	int len = 25;
	int k = 1;
	for(int i = 0 ; i < len ; i++) cout << "*";
	cout << "\n";
	cout << "*";
	for(int i = 1 ; i < len - 1 ; i++) cout << " ";
	cout << "*";
	cout << "\n";
	string s;
	for(auto i : GS) 
	{
		s = "*  " + to_string(k++) + "." + i.GetName();
		for(int j = s.size() ; j < len - 1 ; j++) s += " ";
		s += "*\n";
		cout << s;
	}
	cout << "*";
	for(int i = 1 ; i < len - 1 ; i++) cout << " ";
	cout << "*";
	cout << "\n";
	for(int i = 0 ; i < len ; i++) cout << "*";
	cout << "\n";
	for(int i = 0 ; i < len ; i++) cout << "-";
	cout << "\n";
}

Game* GameSet::GetGame(string name)
{
	int st = 0;
	for(auto i : GS)
	{
		if(i.GetName() == name) return &i;
	}
	return NULL;
}

bool GameSet::AddGame()
{
	if(num == top)
	{
		printf("��Ϸ���������޷�������\n");
		return true;
	}
	num++;
	Game game;
	string s;
	double sc;
	
	do
	{
		cout << "�����µ���Ϸ���ƣ�����0�Է��أ���";
		getline(cin, s);
		if(s == "0") return false;
		else if(FindGameName(s))
		{
			cout << "��ǰ���и���Ϸ���ƣ������������µ���Ϸ���ƣ�\n";
		}
		else
		{
			game.UpdateName(s);	
			break;
		}
			
	}while(1);
	
	do
	{
		cout << "������Ϸ���ͣ�";
		getline(cin, s);
		if(FindDirectory(s)) 
		{
			game.UpdateGenre(s);
			break;
		}
		else
		{
			cout << "��ǰĿ¼�����ڣ�\n";
		}		
	}while(1);

	
	cout << "������Ϸ��ǩ��";
	getline(cin, s);
	game.UpdateTag(s);
	
	do
	{
		cout << "��ƽ̨���֣�0~100�֣���";
		getline(cin, s);
		if(isFloat(s.c_str()))
		{
			sc = strtod(s.c_str(), NULL);
			if(0 <= sc && sc <= 100)
			{
				game.UpdateAvgMedia(sc);
				break;
			}
			else
			{
				cout << "��Ч���룡\n";
			}
		}
		else
		{
			cout << "��Ч���룡\n";
		}		
	}while(1);

	do
	{
		cout << "ý�����֣�0~100�֣���";
		getline(cin, s);
		if(isFloat(s.c_str()))
		{
			sc = strtod(s.c_str(), NULL);
			if(0 <= sc && sc <= 100)
			{
				game.UpdateOtherMedia(sc);
				break;
			}
			else
			{
				cout << "��Ч���룡\n";
			}
		}
		else
		{
			cout << "��Ч���룡\n";
		}		
	}while(1);
	
	
	cout << "��Ϸ����ּ���";
	getline(cin, s);
	game.UpdateAge(s);
	
	cout << "��Ϸ�������ߣ�";
	getline(cin, s);
	game.UpdatePolicy(s);
	
	cout << "��Ϸ���ܣ�";
	getline(cin, s);
	game.UpdateIntro(s);
	

	GS.push_back(game);
	cout << "���ӳɹ���\n";
	return true;
}

bool GameSet::PrintGameByName(string name)
{
	system("cls");
	int st = 0;
	for(auto i : GS)
	{
		if(i.GetName().find(name) != string::npos) 
		{
			cout << "--------------------------------------------------------------------------------------------------------------------------------------------------------\n";
			printf("��Ϸ���ƣ�%s\n", i.GetName().data());
			printf("��Ϸ���ͣ�%s\n", i.GetGenre().data());
			printf("��Ϸ��ǩ��%s\n", i.GetTag().data());
			printf("���ƽ�����֣�%.2f\n",i.GetAvgPlayer());
			printf("��ƽ̨���֣�%.2f\n", i.GetAvgMedia());
			printf("�淨���֣�%.2f\n", i.GetGp());
			printf("�������֣�%.2f\n", i.GetMc());
			printf("�������֣�%.2f\n", i.GetArt());
			printf("�������֣�%.2f\n", i.GetPlot());
			printf("��Ӫ���֣�%.2f\n", i.GetOpt());
			printf("ý�����֣�%.2f\n", i.GetOtherMedia());
			printf("��Ϸ����ּ���%s+\n", i.GetAge().data());
			printf("��Ϸ�������ߣ�%s\n", i.GetPolicy().data());
			printf("��Ϸ���ܣ�%s\n", i.GetIntro().data());
			cout << "--------------------------------------------------------------------------------------------------------------------------------------------------------\n";
			cout << endl << endl;
			st = 1;
		}
	}
	return st;
}

bool GameSet::PrintGameByAge(int age)
{
	int st = 0;
	for(auto i : GS)
	{
		if(stoi(i.GetAge()) <= age) 
		{
			cout << "--------------------------------------------------------------------------------------------------------------------------------------------------------\n";
			printf("��Ϸ���ƣ�%s\n", i.GetName().data());
			printf("��Ϸ���ͣ�%s\n", i.GetGenre().data());
			printf("��Ϸ��ǩ��%s\n", i.GetTag().data());
			printf("���ƽ�����֣�%.2f\n",i.GetAvgPlayer());
			printf("��ƽ̨���֣�%.2f\n", i.GetAvgMedia());
			printf("�淨���֣�%.2f\n", i.GetGp());
			printf("�������֣�%.2f\n", i.GetMc());
			printf("�������֣�%.2f\n", i.GetArt());
			printf("�������֣�%.2f\n", i.GetPlot());
			printf("��Ӫ���֣�%.2f\n", i.GetOpt());
			printf("ý�����֣�%.2f\n", i.GetOtherMedia());
			printf("��Ϸ����ּ���%s+\n", i.GetAge().data());
			printf("��Ϸ�������ߣ�%s\n", i.GetPolicy().data());
			printf("��Ϸ���ܣ�%s\n", i.GetIntro().data());
			cout << "--------------------------------------------------------------------------------------------------------------------------------------------------------\n";
			cout << endl << endl;
			st = 1;
		}
	}	
	return st;
}

bool GameSet::PrintGameByGenre(string genre)
{
	int st = 0;
	for(auto i : GS)
	{
		if(i.GetGenre() == genre) 
		{
			cout << "--------------------------------------------------------------------------------------------------------------------------------------------------------\n";
			printf("��Ϸ���ƣ�%s\n", i.GetName().data());
			printf("��Ϸ���ͣ�%s\n", i.GetGenre().data());
			printf("��Ϸ��ǩ��%s\n", i.GetTag().data());
			printf("���ƽ�����֣�%.2f\n",i.GetAvgPlayer());
			printf("��ƽ̨���֣�%.2f\n", i.GetAvgMedia());
			printf("�淨���֣�%.2f\n", i.GetGp());
			printf("�������֣�%.2f\n", i.GetMc());
			printf("�������֣�%.2f\n", i.GetArt());
			printf("�������֣�%.2f\n", i.GetPlot());
			printf("��Ӫ���֣�%.2f\n", i.GetOpt());
			printf("ý�����֣�%.2f\n", i.GetOtherMedia());
			printf("��Ϸ����ּ���%s+\n", i.GetAge().data());
			printf("��Ϸ�������ߣ�%s\n", i.GetPolicy().data());
			printf("��Ϸ���ܣ�%s\n", i.GetIntro().data());
			cout << "--------------------------------------------------------------------------------------------------------------------------------------------------------\n";
			cout << endl << endl;
			st = 1;
		}
	}		
	return st;
}

void GameSet::InputGame(const char* tb_name)
{
	db->InputGame(tb_name);
	db->ConvertGame(gameset, &num);
	for(int i = 0 ; i < num ; i++) GS.push_back(gameset[i]);
}

void GameSet::ShowGame()
{
	for(int i = 0 ; i < num ; i++) 
	{
		printf("��Ϸ���ƣ�%s\n", gameset[i].GetName().data());
		printf("��Ϸ���ͣ�%s\n", gameset[i].GetGenre().data());
		printf("��Ϸ��ǩ��%s\n", gameset[i].GetTag().data());
		printf("���ƽ�����֣�%.2f\n",gameset[i].GetAvgPlayer());
		printf("��ƽ̨���֣�%.2f\n", gameset[i].GetAvgMedia());
		printf("�淨���֣�%.2f\n", gameset[i].GetGp());
		printf("�������֣�%.2f\n", gameset[i].GetMc());
		printf("�������֣�%.2f\n", gameset[i].GetArt());
		printf("�������֣�%.2f\n", gameset[i].GetPlot());
		printf("��Ӫ���֣�%.2f\n", gameset[i].GetOpt());
		printf("ý�����֣�%.2f\n", gameset[i].GetOtherMedia());
		printf("��Ϸ����ּ���%s+\n", gameset[i].GetAge().data());
		printf("��Ϸ�������ߣ�%s\n", gameset[i].GetPolicy().data());
		printf("��Ϸ���ܣ�%s\n", gameset[i].GetIntro().data());
		cout << endl << endl;
	}	
}

void GameSet::OutputGame(const char* tb_name)
{
	sprintf(sentence, "delete from %s;", tb_name);
	db->Implement(sentence);
	int j = 0;
	for(auto i : GS) gameset[j++] = i;
	for(int i = 0 ; i < num ; i++)
	{
		sprintf(sentence, "insert into %s values ('%s', '%s', '%s', %.2f, %.2f, %.2f, %.2f, %.2f, %.2f, %.2f, %.2f, %.2f, %.2f, %.2f, %.2f, %.2f, '%s', '%s', '%s');", tb_name, gameset[i].GetName().data(), gameset[i].GetGenre().data(), gameset[i].GetTag().data(), gameset[i].GetAvgPlayer(), gameset[i].GetAvgMedia(), gameset[i].GetGp(), gameset[i].GetPowGp(), gameset[i].GetMc(), gameset[i].GetPowMc(), gameset[i].GetArt(), gameset[i].GetPowArt(), gameset[i].GetPlot(), gameset[i].GetPowPlot(), gameset[i].GetOpt(), gameset[i].GetPowOpt(), gameset[i].GetOtherMedia(), gameset[i].GetIntro().data(), gameset[i].GetAge().data(), gameset[i].GetPolicy().data());
		db->Implement(sentence);
	}
} 

bool GameSet::DeleteGame(string name) //ɾ����Ϸ��Ϣ�����֡�Ŀ¼ 
{
	if(num == 0)
	{
//		cout << "��Ϸ�������\n";
		return false;
	}
	
	list<Game>::iterator it = GS.begin();
	while(it != GS.end())
	{
		if((*it).GetName() == name) 
		{
			GS.erase(it);
			num--;
			cout << "ɾ���ɹ���\n";
			return true;
		}
		it++;
	}
//	cout << "�Ҳ�����Ҫ�ҵ���Ϸ��\n";
	return false;
}

bool GameSet::UpdateGame(string name) //�޸���Ϸ��Ϣ�����֡�Ŀ¼ 
{
	list<Game>::iterator it = GS.begin();
	Game* g = &(*it);
	while(it != GS.end())
	{
		if(g->GetName() == name) break;
		it++;
		g = &(*it);
	}
	if(it == GS.end()) 
	{
		cout << "�Ҳ�����Ҫ�޸ĵ���Ϸ��\n";
		return false;
	}
	else
	{
		do
		{
			system("cls");
			cout << "**************************\n";
			cout << "*                        *\n";
			cout << "*  1.��Ϸ����            *\n";
			cout << "*  2.��Ϸ����            *\n";
			cout << "*  3.��Ϸ��ǩ            *\n";
			cout << "*  4.��ƽ̨����          *\n";
			cout << "*  5.ý������            *\n";
			cout << "*  6.��Ϸ����ּ�        *\n";
			cout << "*  7.��Ϸ��������        *\n";
			cout << "*  8.��Ϸ����            *\n";
			cout << "*  9.һ���޸���������    *\n";
			cout << "*  0.����                *\n";
			cout << "*                        *\n";
			cout << "**************************\n";
			cout << "---------------------------\n";
			printf("������ѡ�");
			string choice;
			double sc;
			string s;
			getline(cin, choice);
			cout << "---------------------------\n";
			if(choice == "1")
			{
				do
				{
					cout << "�������µ���Ϸ���ƣ�";
					getline(cin, s);
					if(!this->FindGameName(s)) 
					{
						g->UpdateName(s);
						break;
					}
					else
					{
						cout << "��ǰ��Ϸ�����Ѵ��ڣ�\n";
					}					
				}while(1);
				cout << "�޸ĳɹ���\n";	

			}
			else if(choice == "2")
			{
				do
				{
					cout << "�������µ���Ϸ���ͣ�";
					getline(cin, s);
					if(FindDirectory(s)) 
					{
						g->UpdateGenre(s);
						break;
					}
					else
					{
						cout << "��ǰĿ¼�����ڣ�\n";
					}
										
				}while(1);
				cout << "�޸ĳɹ���\n";	
				system("pause");

			}
			else if(choice == "3")
			{
				cout << "�������µ���Ϸ��ǩ��";
				getline(cin, s);
				g->UpdateTag(s);
				cout << "�޸ĳɹ���\n";	
				system("pause");	
			}
			else if(choice == "4")
			{
				do
				{
					cout << "�µı�ƽ̨���֣�0~100�֣���";
					getline(cin, s);
					if(isFloat(s.c_str()))
					{
						sc = strtod(s.c_str(), NULL);
						if(0 <= sc && sc <= 100)
						{
							g->UpdateAvgMedia(sc);
							break;
						}
						else
						{
							cout << "��Ч���룡\n";
						}
					}
					else
					{
						cout << "��Ч���룡\n";
					}		
				}while(1);
				cout << "�޸ĳɹ���\n";	
				system("pause");
			}
			else if(choice == "5")
			{
				do
				{
					cout << "�µ�ý�����֣�0~100�֣���";
					getline(cin, s);
					if(isFloat(s.c_str()))
					{
						sc = strtod(s.c_str(), NULL);
						if(0 <= sc && sc <= 100)
						{
							g->UpdateOtherMedia(sc);
							break;
						}
						else
						{
							cout << "��Ч���룡\n";
						}
					}
					else
					{
						cout << "��Ч���룡\n";
					}		
				}while(1);
				cout << "�޸ĳɹ���\n";	
				system("pause");
			}
			else if(choice == "6")
			{
				cout << "�������µ���Ϸ����ּ���";
				getline(cin, s);
				g->UpdateAge(s);	
				cout << "�޸ĳɹ���\n";
				system("pause");	
			}
			else if(choice == "7")
			{
				cout << "�������µ���Ϸ�������ߣ�";
				getline(cin, s);
				g->UpdatePolicy(s);		
				cout << "�޸ĳɹ���\n";	
				system("pause");				
			}
			else if(choice == "8")
			{
				cout << "�������µ���Ϸ���ܣ�";
				getline(cin, s);
				g->UpdateIntro(s);	
				cout << "�޸ĳɹ���\n";	
				system("pause");
			}
			else if(choice == "9")
			{
				//change Name
				cout << "�������µ���Ϸ���ƣ�";
				getline(cin, s);
				g->UpdateName(s);
				
				//change Genre
				cout << "�������µ���Ϸ���ͣ�";
				getline(cin, s);
				g->UpdateGenre(s);
				
				//change Tag
				cout << "�������µ���Ϸ��ǩ��";
				getline(cin, s);
				g->UpdateTag(s);	
				
				
				//change media
				do
				{
					cout << "�µı�ƽ̨���֣�0~100�֣���";
					getline(cin, s);
					if(isFloat(s.c_str()))
					{
						sc = strtod(s.c_str(), NULL);
						if(0 <= sc && sc <= 100)
						{
							g->UpdateAvgMedia(sc);
							break;
						}
						else
						{
							cout << "��Ч���룡\n";
						}
					}
					else
					{
						cout << "��Ч���룡\n";
					}		
				}while(1);
				
				
				//change other_media
				do
				{
					cout << "�µ�ý�����֣�0~100�֣���";
					getline(cin, s);
					if(isFloat(s.c_str()))
					{
						sc = strtod(s.c_str(), NULL);
						if(0 <= sc && sc <= 100)
						{
							g->UpdateOtherMedia(sc);
							break;
						}
						else
						{
							cout << "��Ч���룡\n";
						}
					}
					else
					{
						cout << "��Ч���룡\n";
					}		
				}while(1);
				
				//change age
				cout << "�������µ���Ϸ����ּ���";
				getline(cin, s);
				g->UpdateAge(s);
				
				//change policy
				cout << "�������µ���Ϸ�������ߣ�";
				getline(cin, s);
				g->UpdatePolicy(s);	
				
				//change intro
				cout << "�������µ���Ϸ���ܣ�";
				getline(cin, s);
				g->UpdateIntro(s);	
				system("pause");
			}
			else if(choice == "0")
			{
				return true;
			}
			else
			{
				cout << "��Ч���룡";
				system("pause");
			}
		}while(1);
	}
}

//Ŀ¼����ģ��


class Directory
{
	public:
		void InputPreOrder(DT* rt, int* k, int num);
		
		void OutputPreOrder(DT* rt, int* k, int num, const char* tb_name);
		
		void InputDirectory(const char* tb_name);
		
		void ShowDirectory();
		
		void OutputDirectory(const char* tb_name);
		
		void ShowDT(DT* rt, int h);
		
		bool ShowCurrentDT(DT* rt);
		
		void ShowSubDT(DT* rt, GameSet* gs);
		
		DT* FindTheDT(DT* rt, string genre);
		
		DT* GetDT();
		
		void UpdateLR(DT* rt, int* n, int* k);
		
		DT* EnterNextDT(DT* rt, int k);
		
		Directory(Database* Db) {
			dt = new DT;
			db = Db;
			num = 0;
		}
		
		void Numplus()
		{
			num++;
		}
		
		void NumSub() {
			num--;
		}
		
		bool FindDirectory(string genre);
	
	private:
		DT* dt;
		Database* db;
		Node nodes[100];
		int num;
		char sentence[1000];
};

bool Directory::FindDirectory(string genre)
{
	for(int i = 0 ; i < num ; i++)
	{
		if(nodes[i].genre == genre) return true;
	}
	return false;	
}

DT* Directory::FindTheDT(DT* rt, string genre)
{
	if(rt == NULL) return NULL;
	for(auto sdt : rt->SDT)
	{
		if(sdt->genre == genre) return sdt;
	}
	return NULL;
}

DT* Directory::GetDT()
{
	return dt;
}

void Directory::UpdateLR(DT* rt, int* n, int* k)
{
	if(rt == NULL) return ;
	int p = (*n)++;
	nodes[p].genre = rt->genre;
	nodes[p].left = ++(*k);
	for(auto sdt : rt->SDT)
	{
		UpdateLR(sdt, n, k);
	}
	nodes[p].right = ++(*k);
//	cout << nodes[p].genre << ' ' << nodes[p].left << ' ' << nodes[p].right << endl;
}

void Directory::InputPreOrder(DT* rt, int* k, int num)
{
	rt->genre = nodes[*k].genre;
	int kk = *k;
	
	(*k)++;
	while(*k < num && nodes[kk].left < nodes[*k].left && nodes[kk].right > nodes[*k].right)
	{
		DT* t = new DT;
		t->fa = rt;
		InputPreOrder(t, k, num);
		rt->SDT.push_back(t);
			
		cout << t->genre << endl;				
	}
}

void Directory::OutputPreOrder(DT* rt, int* k, int num, const char* tb_name)
{
	sprintf(sentence, "insert into %s values ('%s', %d, %d);", tb_name, nodes[*k].genre.data(), nodes[*k].left, nodes[*k].right);
	db->Implement(sentence);
	if(nodes[*k].right == nodes[*k].left + 1) return ;
	
	while(*k < num)
	{
		DT* t = new DT;
		(*k)++;
		if(*k < num) OutputPreOrder(t, k, num, tb_name);
	}
}

void Directory::OutputDirectory(const char* tb_name)
{
	
	sprintf(sentence, "delete from %s;", tb_name);
	db->Implement(sentence);
	int n, k;
	n = k = 0;
	UpdateLR(dt, &n, &k);
	k = 0;
	OutputPreOrder(dt, &k, num, tb_name);
}

void Directory::ShowDT(DT* rt, int h)
{
	if(rt == NULL) return ;
	if(rt->genre != "Root") 
	{
		cout << h << '.' << rt->genre << endl;
	}
	for(auto sdt : rt->SDT)
	{
		ShowDT(sdt, h + 1);
	}
}

void Directory::ShowSubDT(DT* rt, GameSet* gs)
{
	if(rt == NULL) return ;
	if(rt->genre != "Root") gs->PrintGameByGenre(rt->genre);
	for(auto sdt : rt->SDT)
	{
		ShowSubDT(sdt, gs);
	}
}

bool Directory::ShowCurrentDT(DT* rt)
{
	int st = 0;
	int i = 1;
	for(auto sdt : rt->SDT)
	{
		st = 1;
		cout << i << '.' << sdt->genre << endl;
		i++;
	}
	return st;
}

DT* Directory::EnterNextDT(DT* rt, int k)
{
	int i = 0;
	int st = 0;
	for(auto sdt : rt->SDT)
	{
		i++;
		if(k == i) 
		{
			st = 1;
			return sdt;
		}
	}
	if(!st) 
	{
		cout << "�Ҳ�����Ҫ��ѯ��Ŀ¼��\n";
		return NULL;
	}
}

void Directory::ShowDirectory()
{
	ShowDT(dt, 0);
}

void Directory::InputDirectory(const char* tb_name)
{
	db->InputDirectory(tb_name);
	db->ConvertDirectory(nodes, &num);
	int k = 0;
	InputPreOrder(dt, &k, num);
} 

class User
{
	public:
		string GetId() {
			return id;
		}
		
		string GetPassword() {
			return password;
		}

		void UpdateId(string id) {
			this->id = id;
		}
		
		void UpdatePassword(string password) {
			this->password = password;
		}
		
		void UpdateGp(double gp) {
			this->gp = gp;
		}
		
		void UpdateMc(double mc) {
			this->mc = mc;
		}
		
		void UpdateArt(double art) {
			this->art = art;
		}
		
		void UpdatePlot(double plot) {
			this->plot = plot;
		}
		
		void UpdateOpt(double opt) {
			this->opt = opt;
		}
		
		double GetGp() {
			return gp;
		}
		
		double GetMc() {
			return mc;
		}
		
		double GetArt() {
			return art;
		}
		
		double GetPlot() {
			return plot;
		}
		
		double GetOpt() {
			return opt;
		}
		
		User() {
			id = "";
			password = "";
			gp = mc = art = plot = opt = 0;
		}
	
	private:
		string id;
		string password;
		double gp;
		double mc;
		double art;
		double plot;
		double opt;
};

Database database;
User* user;
GameSet* gs;
Directory* dc;

//������
void BeginUI()
{
	cout<<"**********************\n";
	cout<<"*                    *\n";
	cout<<"*  ������Ϸ����ϵͳ  *\n";
	cout<<"*                    *\n";
	cout<<"*     1.�û���¼     *\n";
	cout<<"*                    *\n";
	cout<<"*     2.����Ա��¼   *\n";
	cout<<"*                    *\n";
	cout<<"*     3.ע��         *\n";
	cout<<"*                    *\n";	
	cout<<"*     0.�˳�         *\n";	
	cout<<"*                    *\n";	
	cout<<"**********************\n";
	cout<<"----------------------\n";
}

void ViHomepageUI() //�ο���ҳ 
{
 		cout<<"************************\n";
		cout<<"*                      *\n";
		cout<<"*     1.��ѯ��Ϸ       *\n";
		cout<<"*                      *\n";
		cout<<"*     2.������Ϸ       *\n";
		cout<<"*                      *\n";
		cout<<"*     0.����           *\n";
		cout<<"*                      *\n";	
		cout<<"************************\n";
		cout<<"------------------------\n";	
}

void ViHomepage()
{
	string choice;
	do
	{
		cin.sync();
		system("cls");
		ViHomepageUI();
		printf("������ѡ�");
		cin >> choice;
		if(choice == "0")
		{
			return ;
		}	
		else if(choice == "1")
		{
			Search();
		}
		else if(choice == "2")
		{
			ScoreOp();
		}
		else
		{
			cout<<"��Ч���룡\n";
			system("pause");
		}
	}while(1);
	 
}

void ViLogin() //�û���¼ 
{
	cin.sync();
	string userid;//�û�id
	string password;//����
	cout<<"----------------------\n";
	cout << "�������˺�������\n";
	cout << "�˺ţ�";
	cin >> userid;
	cout << "���룺";
	cin >> password;
	if(database.QueryUser("player", userid.data(), password.data()))
	{
		user->UpdateId(userid);
		user->UpdatePassword(password);
		cout << "��¼�ɹ���\n";
		system("pause");
		ViHomepage();	
	}
	else
	{
		cout << "�˺Ż��������\n";
		system("pause");
	}
//	SetCursor(1,1); 
} 

void MaHomepageUI() //����Ա��ҳ 
{
	cout << "************************\n";
	cout << "*                      *\n";
	cout << "*     1.��ѯ��Ϸ       *\n";
	cout << "*                      *\n";
	cout << "*     2.������Ϸ       *\n";
	cout << "*                      *\n";
	cout << "*     3.������Ϸ��     *\n";
	cout << "*                      *\n";	
	cout << "*     0.����           *\n";
	cout << "*                      *\n";	
	cout << "************************\n";
	cout <<	"------------------------\n";
} 

void MaHomepage()
{
	string choice;
	do
	{
		cin.sync();
		system("cls");
		MaHomepageUI();
		printf("������ѡ�");
		cin >> choice;
		if(choice == "0")
		{
			return ;
		}	
		else if(choice == "1")
		{
			Search();
		}
		else if(choice == "2")
		{
			ScoreOp();
		}
		else if(choice == "3")
		{
			MaControl();
		}
		else
		{
			cout << "��Ч���룡\n";
			system("pause");
		}
	}while(1);
}

void MaLogin() //����Ա��¼ 
{
	cin.sync();
	string userid;//�û�id
	string password;//����
	cout<<"----------------------\n";
	cout << "�������˺�������\n";
	cout << "�˺ţ�"; 
	cin >> userid;
	cout << "���룺"; 
	cin >> password;
	if(database.QueryUser("manager", userid.data(), password.data()))
	{
		user->UpdateId(userid);
		user->UpdatePassword(password);
		cout << "��¼�ɹ���\n";
		system("pause");
		MaHomepage();	
	}
	else
	{
		cout << "�˺Ż��������\n";
		system("pause");
	}
}

void SignUI()
{
	cout<<"**********************\n";
	cout<<"*                    *\n";
	cout<<"*     1.�ο�ע��     *\n";
	cout<<"*                    *\n";
	cout<<"*     2.����Աע��   *\n";
	cout<<"*                    *\n";	
	cout<<"*     0.����         *\n";	
	cout<<"*                    *\n";	
	cout<<"**********************\n";
	cout<<"----------------------\n";		
}

void Sign()
{
	string choice;
	string userid;//�û�id
	string password;//����
	string viword;//������
	do
	{
		system("cls");
		SignUI();
		cout << "������ѡ��(���)��"; 
		cin >> choice;
		if(choice == "1")
		{
			cout << "�������˺ź�����\n";
			cout << "�˺ţ�"; 
			cin >> userid;
			cout << "���룺"; 
			cin >> password;
			database.OutputUser("player", userid, password);
			cout << "ע��ɹ���\n";
			system("pause");
			return ;
		}
		else if(choice == "2")
		{
			cout << "�������˺ź�����\n";
			cout << "�˺ţ�"; 
			cin >> userid;
			cout << "���룺"; 
			cin >> password;
			cout << "�����룺";
			cin >> viword;
			if(viword == "2024") 
			{
				cout << "ע��ɹ���\n";
				database.OutputUser("manager", userid, password);
			}
			else cout << "ע��ʧ�ܣ�\n";
			system("pause");
			return ;
		}
		else if(choice == "0")
		{
			return ;
		} 
		else
		{
			cout << "��Ч���룡\n";
			system("pause");
		}
	}while(1);
} 

void Begin()
{
	database.Connect(HOST, USERNAME, PASSWORD, DATABASE, PORT);
	user = new User;
	gs = new GameSet(&database);
	dc = new Directory(&database);
	gs->InputGame("gs");
	gs->AllAvgPlayer();
	dc->InputDirectory("nodes");
	dc->ShowDT(dc->GetDT(), 0);
//	return ;
	system("cls");
	
	string input;
	do
	{
		cin.sync();
		system("cls");
		BeginUI();
		printf("������ѡ�");
		getline(cin, input);
		if(input == "1")
		{
			ViLogin();
		}	
		else if(input == "2")
		{
			MaLogin();
		}
		else if(input == "3")
		{
			Sign();
		}
		else if(input == "0")
		{
			gs->OutputGame("gs");
			dc->OutputDirectory("nodes");
			return ;
		}
		else 
		{
			cout << "��Ч���룡\n";
			system("pause");
		}
	}while(1);
} 
 
void SearchUI()
{
	cout<<"*************************\n";
	cout<<"*                       *\n";
	cout<<"*    1.������Ϸ����     *\n";
	cout<<"*                       *\n";
	cout<<"*    2.�����Ϸ��       *\n";
	cout<<"*                       *\n";
	cout<<"*    0.����             *\n";
	cout<<"*                       *\n";
	cout<<"*************************\n";
	cout<<"-------------------------\n";
}

void Search1()
{
	do
	{
		cin.sync();
		system("cls");
		gs->PrintGameName();
		string name;
		cout << "��������Ϸ����(����0���˳�)��";
		cin >> name;
		system("cls");
		if(gs->PrintGameByName(name)) 
		{
			system("pause");
			return ;
		}
		else 
		{
			if(name == "0") return ;
			cout << "�Ҳ���Ҫ��ѯ����Ϸ��" << endl;
			system("pause");
		}
	}while(1);
}


//�ּ� 

void BrowsUI1()
{
	cout<<"**********************\n";
	cout<<"*                    *\n";
	cout<<"*        1.12+       *\n";
	cout<<"*                    *\n";
	cout<<"*        2.16+       *\n";
	cout<<"*                    *\n";
	cout<<"*        3.18+       *\n";
	cout<<"*                    *\n";
	cout<<"**********************\n";
	cout<<"----------------------\n";
}

void BrowsUI2()
{
	cout << "**************************************\n";
	cout << "*                                    *\n";
	cout << "*             ��ܰ��ʾ               *\n";
	cout << "*                                    *\n";
	cout << "*  1.�����Ӧ��ţ�������һĿ¼      *\n";
	cout << "*  2.����back����������һĿ¼        *\n";
	cout << "*  3.������Ϸ�������ƣ�չʾ�����Ϸ  *\n";
	cout << "*  4.����0�Է���                     *\n";
	cout << "*                                    *\n";
	cout << "**************************************\n";
	cout << "--------------------------------------\n";
}

void Brows1()//����ּ� 
{
	
	string choice;
	int age;
	int st = 1;
	do
	{
		cin.sync();
		system("cls");
		BrowsUI1();
		cout << "������ѡ�";
		getline(cin, choice);
		cout<<"----------------------\n";
		if(choice == "1")
		{
			age=12;
			system("cls");
			gs->PrintGameByAge(age);
			st = 0;
			system("pause");
		}
		else if(choice == "2")
		{
			age=16;
			system("cls");
			gs->PrintGameByAge(age);
			st = 0;
			system("pause");
		}
		else if(choice == "3")
		{
			age=18;
			system("cls");
			gs->PrintGameByAge(age);
			st = 0;
			system("pause");
		}
		else
		{
			printf("��Ч���룡\n");
			system("pause");
		}
	}while(st);
}

void Brows2()//�淨���� 
{
	
	string genre;
	DT* nowDT = dc->GetDT();
	DT* kDT = NULL;
	do
	{
		cin.sync();
		system("cls");	
		BrowsUI2();
		cout << "\n";
		cout << "��Ϸ����Ŀ¼��\n";
		dc->ShowCurrentDT(nowDT);
		cout << "\n";
		cout << "--------------------------------------\n";
		cout << "������Ҫ���ҵ���Ϸ���ͣ�";
		getline(cin, genre);
		int k = FindNum(genre);
		DT* p = dc->FindTheDT(nowDT, genre);
		if(p != NULL)
		{
			system("cls");
			dc->ShowSubDT(p, gs);
			system("pause");
		}
		else if(genre == "0") 
		{
			return ;
		}
		else if(k != -1 && (kDT = dc->EnterNextDT(nowDT, k)) != NULL)
		{
			if(dc->ShowCurrentDT(kDT)) nowDT = kDT;
			else 
			{
				system("cls");
				cout << "��ǰ�Ѿ�������Ŀ¼��!" << endl;
				system("pause");
			}
		}
		else if(genre == "back")
		{
			kDT = nowDT->fa;
			if(kDT != NULL) nowDT = kDT;
			else
			{
				system("cls");
				cout << "��ǰ�Ѿ�������Ŀ¼����" << endl;
				system("pause"); 
			}
		}
		else
		{
			system("cls");
			cout << "û����Ҫ�ҵ���Ϸ����Ŷ!" << endl;
			system("pause");
		}
		
	}while(1);
}

void BrowsUI()
{
	cout<<"**********************\n";
	cout<<"*                    *\n";
	cout<<"*      1.����ּ�    *\n";
	cout<<"*                    *\n";
	cout<<"*      2.�淨����    *\n";
	cout<<"*                    *\n";
	cout<<"*      0.����        *\n";
	cout<<"*                    *\n";	
	cout<<"**********************\n";
	cout<<"----------------------\n";	
}

void Brows()
{
	string choice;
	do
	{
		cin.sync();
		system("cls");
		BrowsUI();
		cout<<"������ѡ�";
		getline(cin, choice);
		if(choice == "1")
		{
			Brows1();
		}
		else if(choice == "2")
		{
			Brows2();
		}
		else if(choice == "0")
		{
			return ;
		}
		else
		{
			cout << "��Ч���룡\n";
			system("pause");
		}
	}while(1);
}

void Search()
{
	string choice;
	do
	{
		system("cls");
		SearchUI();
		cout << "������ѡ�";
		cin >> choice;
		if(choice == "1")
		{
			Search1();
		}
		else if(choice == "2")
		{
			Brows();
		}
		else if(choice == "0") 
		{
			return ;
		}
		else
		{
			cout << "��Ч���룡\n";
			system("pause");
		}
	}while(1);
}

void MaControlUI()//�������� 
{
    cout<<"****************************\n";
    cout<<"*                          *\n";
    cout<<"*      1.������ϷĿ¼      *\n";
    cout<<"*                          *\n";
    cout<<"*      2.��������Ȩ��      *\n";
    cout<<"*                          *\n";
    cout<<"*      3.������Ϸ��Ϣ      *\n";
    cout<<"*                          *\n";
    cout<<"*      0.����              *\n";
    cout<<"*                          *\n";
    cout<<"****************************\n";
    cout<<"----------------------------\n";
} 
 
void MaControlUI1()
{
    cout<<"****************************\n";
    cout<<"*                          *\n";
    cout<<"*      1.������ϷĿ¼      *\n";
    cout<<"*                          *\n";
    cout<<"*      2.ɾ����ϷĿ¼      *\n";
    cout<<"*                          *\n";
    cout<<"*      3.�޸���ϷĿ¼      *\n";
    cout<<"*                          *\n";
    cout<<"*      0.����              *\n";
    cout<<"*                          *\n";
    cout<<"****************************\n";
    cout<<"----------------------------\n";
}

void MaControlUI2()
{
    cout<<"****************************\n";
    cout<<"*                          *\n";
    cout<<"*      1.��ѯ����Ȩ��      *\n";
    cout<<"*                          *\n";
    cout<<"*      2.�޸�����Ȩ��      *\n";
    cout<<"*                          *\n";
    cout<<"*      3.ɾ����ϷȨ��      *\n";
    cout<<"*                          *\n";
    cout<<"*      0.����              *\n";
    cout<<"*                          *\n";
    cout<<"****************************\n";
    cout<<"----------------------------\n";
}

void MaControlUI3()
{
    cout<<"****************************\n";
    cout<<"*                          *\n";
    cout<<"*      1.������Ϸ��Ϣ      *\n";
    cout<<"*                          *\n";
    cout<<"*      2.ɾ����Ϸ��Ϣ      *\n";
    cout<<"*                          *\n";
    cout<<"*      3.�޸���Ϸ��Ϣ      *\n";
    cout<<"*                          *\n";
    cout<<"*      0.����              *\n";
    cout<<"*                          *\n";
    cout<<"****************************\n";
    cout<<"----------------------------\n";
}

void MaControl()
{
	string choice;
	do
	{
		cin.sync();
		system("cls");
		MaControlUI();
		cout<<"������ѡ�";
		getline(cin, choice);
		if(choice == "1")
		{
			MaControl1();
		}
		else if(choice == "2")
		{
			MaControl2();
		}
		else if(choice == "3")
		{
			MaControl3();
		}
		else if(choice == "0")
		{
			return ;
		}
		else
		{
			cout << "��Ч���룡\n";
			system("pause");
		}
	}while(1);
}

void MaControl1()
{
	string choice;
	do
	{
		cin.sync();
		system("cls");
		MaControlUI1();
		cout<<"������ѡ�";
		getline(cin, choice);
		cout<<"----------------------------\n";
		if(choice == "1")
		{
			AddGameDirectory();
			system("pause");
		}
		else if(choice == "2")
		{
			DeleteGameDirectory();
			system("pause");
		}
		else if(choice == "3")
		{
			UpdateGameDirectory();
			system("pause");
		}
		else if(choice == "0")
		{
			return ;
		}
		else
		{
			cout << "��Ч���룡\n";
			system("pause");
		}
	}while(1);	
}

void MaControl2()
{
	string choice;
	do
	{
		cin.sync();
		system("cls");
		MaControlUI2();
		cout<<"������ѡ�";
		getline(cin, choice);
		cout<<"----------------------------\n";
		if(choice == "1")
		{
			string name;
			do
			{
				system("cls");
				gs->PrintGameName();
				cout << "��������Ϸ���ƣ�����0�Է��أ���";
				getline(cin, name);
				if(name == "0") return ;
				else if(gs->ShowGamePow(name)) ;
				else cout << "��Ч���룡\n";
				system("pause");
			}while(1);			
		}
		else if(choice == "2")
		{
			string name;
			do
			{
				system("cls");
				gs->PrintGameName();
				cout << "��������Ϸ���ƣ�����0�Է��أ���";
				getline(cin, name);
				if(name == "0") return ;
				else if(gs->UpdateGamePow(name)) ;
				else cout << "��Ч���룡\n";
				system("pause");
			}while(1);

		}
		else if(choice == "3")
		{
			string name;
			do
			{
				system("cls");
				gs->PrintGameName();
				cout << "��������Ϸ���ƣ�����0�Է��أ���";
				getline(cin, name);
				if(name == "0") return ;
				else if(gs->DeleteGamePow(name)) ;
				else cout << "��Ч���룡\n";
				system("pause");				
			}while(1);
		}
		else if(choice == "0")
		{
			return ;
		}
		else
		{
			cout << "��Ч���룡\n";
			system("pause");
		}
	}while(1);
}

void MaControl3()
{
	string choice;
	do
	{
		cin.sync();
		system("cls");
		MaControlUI3();
		cout << "������ѡ�";
		getline(cin, choice);
//		cout << "----------------------------\n";
		if(choice == "1")
		{
			do
			{
				system("cls");
				gs->PrintGameName();
				if(!gs->AddGame()) break;
				system("pause");				
			}
			while(1);
		}
		else if(choice == "2")
		{
			string name;
			do
			{
				system("cls");
				gs->PrintGameName();
				cout << "������Ҫɾ������Ϸ���ƣ�����0�Է��أ���";
				getline(cin, name);
				if(name == "0") break;
				else if(gs->DeleteGame(name)) ;
				else cout << "��Ч���룡\n";
				system("pause");				
			}while(1);
		}
		else if(choice == "3")
		{
			string name;
			do
			{
				system("cls");
				gs->PrintGameName();
				cout << "������Ҫ�޸ĵ���Ϸ���ƣ�����0�Է��أ���";
				getline(cin, name);
				if(name == "0") break;
				else if(gs->UpdateGame(name)) ;
				else 
				{
					cout << "��Ч���룡\n";
					system("pause");					
				}
			}while(1);
		}
		else if(choice == "0")
		{
			return ;
		}
		else
		{
			cout << "��Ч���룡\n";
			system("pause");
		}
	}while(1);
}

void ScoreUI()
{
	cout << "****************************\n";
	cout << "*                          *\n";
	cout << "*  1.�鿴��ǰ��Ϸ����      *\n";
	cout << "*  2.�����淨����          *\n";
	cout << "*  3.������������          *\n";
	cout << "*  4.������������          *\n";
	cout << "*  5.���þ�������          *\n";
	cout << "*  6.������Ӫ����          *\n";
	cout << "*  7.һ����������          *\n";
	cout << "*  0.����                  *\n";
	cout << "*                          *\n";
	cout << "****************************\n";
	cout << "----------------------------\n";
}

void ScoreOp()
{
	string choice;
	string name;
	string s;
	double sc;
	do
	{
		cin.sync();
		system("cls");
		gs->PrintGameName();
		cout << "����������Ҫ���ֵ���Ϸ���ƣ�����0�Է��أ���";
		getline(cin, name); 
		if(name == "0") return ;
		if(!gs->FindGameName(name)) 
		{
			cout << "�Ҳ�����Ҫ���ҵ���Ϸ��\n";
			system("pause");
		}
		else
		{
			break;
		}			
	}while(1);
	
	do
	{
		system("cls");
		ScoreUI();
		cout << "������ѡ�";
		getline(cin, choice);
		cout << "----------------------------\n";
		if(choice == "1")
		{
			if(database.QueryScore("score", user->GetId().data(), name.data()))
			{
				double gp, mc, art, plot, opt;
				database.GetScore("score", user->GetId().data(), name.data(), &gp, &mc, &art, &plot, &opt);
				user->UpdateGp(gp);
				user->UpdateMc(mc);
				user->UpdateArt(art);;
				user->UpdatePlot(plot);
				user->UpdateOpt(opt);
				database.PrintRate("score", user->GetId().data(), name.data());
			}
			else
			{
				cout << "��Ϸ���ƣ�" << name << endl;
				cout << "�淨���֣�" << "0.00" << endl;
				cout << "�������֣�" << "0.00" << endl;
				cout << "�������֣�" << "0.00" << endl;
				cout << "�������֣�" << "0.00" << endl;
				cout << "��Ӫ���֣�" << "0.00" << endl;
			} 
			system("pause");
		}
		else if(choice == "2")
		{
			do
			{
				cout << "�������淨���֣�0~5�֣���";
				getline(cin, s);
				if(isFloat(s.c_str()))
				{
					sc = strtod(s.c_str(), NULL);
					if(0 <= sc && sc <= 5)
					{
						if(database.QueryScore("score", user->GetId().data(), name.data()))
						{
							double gp, mc, art, plot, opt;
							database.GetScore("score", user->GetId().data(), name.data(), &gp, &mc, &art, &plot, &opt);
							user->UpdateGp(gp);
							user->UpdateMc(mc);
							user->UpdateArt(art);;
							user->UpdatePlot(plot);
							user->UpdateOpt(opt);
							
							user->UpdateGp(sc);
							database.UpdateScore("score", user->GetId().data(), name.data(), user->GetGp(), user->GetMc(), user->GetArt(), user->GetPlot(), user->GetOpt());
						}
						else
						{
							user->UpdateGp(sc);
							database.AddScore("score", user->GetId().data(), name.data(), user->GetGp(), user->GetMc(), user->GetArt(), user->GetPlot(), user->GetOpt());
						}
						gs->UpdateGameRate("score", "�淨", name);	
						gs->AvgPlayer(name);
						cout << "���óɹ���\n";			
						system("pause");
						break;					
					}
					else
					{
						cout << "����ʧ�ܣ�\n";
					}
				}
				else
				{
					cout << "����ʧ�ܣ�\n";
				}				
			}while(1);

		}
		else if(choice == "3")
		{
			do
			{
				cout << "�������������֣�0~5�֣���";
				getline(cin, s);
				if(isFloat(s.c_str()))
				{
					sc = strtod(s.c_str(), NULL);
					if(0 <= sc && sc <= 5)
					{
						if(database.QueryScore("score", user->GetId().data(), name.data()))
						{
							double gp, mc, art, plot, opt;
							database.GetScore("score", user->GetId().data(), name.data(), &gp, &mc, &art, &plot, &opt);
							user->UpdateGp(gp);
							user->UpdateMc(mc);
							user->UpdateArt(art);;
							user->UpdatePlot(plot);
							user->UpdateOpt(opt);
							
							user->UpdateMc(sc);
							database.UpdateScore("score", user->GetId().data(), name.data(), user->GetGp(), user->GetMc(), user->GetArt(), user->GetPlot(), user->GetOpt());
						}
						else
						{
							user->UpdateMc(sc);
							database.AddScore("score", user->GetId().data(), name.data(), user->GetGp(), user->GetMc(), user->GetArt(), user->GetPlot(), user->GetOpt());
						}
						gs->UpdateGameRate("score", "����", name);
						gs->AvgPlayer(name);			
						cout << "���óɹ���\n";	
						system("pause");
						break;				
					}
					else
					{
						cout << "����ʧ�ܣ�\n";
					}
				}
				else
				{			
					cout << "����ʧ�ܣ�\n";
				}				
			}while(1);	
		}
		else if(choice == "4")
		{
			do
			{
				cout << "�������������֣�0~5�֣���";
				getline(cin, s);
				if(isFloat(s.c_str()))
				{
					sc = strtod(s.c_str(), NULL);
					if(0 <= sc && sc <= 5)
					{
						if(database.QueryScore("score", user->GetId().data(), name.data()))
						{
							double gp, mc, art, plot, opt;
							database.GetScore("score", user->GetId().data(), name.data(), &gp, &mc, &art, &plot, &opt);
							user->UpdateGp(gp);
							user->UpdateMc(mc);
							user->UpdateArt(art);;
							user->UpdatePlot(plot);
							user->UpdateOpt(opt);
							
							user->UpdateArt(sc);
							database.UpdateScore("score", user->GetId().data(), name.data(), user->GetGp(), user->GetMc(), user->GetArt(), user->GetPlot(), user->GetOpt());
						}
						else
						{
							user->UpdateArt(sc);
							database.AddScore("score", user->GetId().data(), name.data(), user->GetGp(), user->GetMc(), user->GetArt(), user->GetPlot(), user->GetOpt());
						}
						gs->UpdateGameRate("score", "����", name);
						gs->AvgPlayer(name);	
						cout << "���óɹ���\n";				
						system("pause");
						break;					
					}
					else
					{
						cout << "����ʧ�ܣ�\n";
					}
				}
				else
				{
					cout << "����ʧ�ܣ�\n";
				}				
			}while(1);
		}
		else if(choice == "5")
		{
			do
			{
				cout << "������������֣�0~5�֣���";
				getline(cin, s);
				if(isFloat(s.c_str()))
				{
					sc = strtod(s.c_str(), NULL);
					if(0 <= sc && sc <= 5)
					{
						if(database.QueryScore("score", user->GetId().data(), name.data()))
						{
							double gp, mc, art, plot, opt;
							database.GetScore("score", user->GetId().data(), name.data(), &gp, &mc, &art, &plot, &opt);
							user->UpdateGp(gp);
							user->UpdateMc(mc);
							user->UpdateArt(art);;
							user->UpdatePlot(plot);
							user->UpdateOpt(opt);
							
							user->UpdatePlot(sc);
							database.UpdateScore("score", user->GetId().data(), name.data(), user->GetGp(), user->GetMc(), user->GetArt(), user->GetPlot(), user->GetOpt());
						}
						else
						{
							user->UpdatePlot(sc);
							database.AddScore("score", user->GetId().data(), name.data(), user->GetGp(), user->GetMc(), user->GetArt(), user->GetPlot(), user->GetOpt());
						}
						gs->UpdateGameRate("score", "����", name);
						gs->AvgPlayer(name);					
						cout << "���óɹ���\n";	
						system("pause");
						break;				
					}
					else
					{
						cout << "����ʧ�ܣ�\n";
					}
				}
				else
				{
					cout << "����ʧ�ܣ�\n";
				}				
			}while(1);
		}
		else if(choice == "6")
		{
			do
			{
				cout << "��������Ӫ���֣�0~5�֣���";
				getline(cin, s);
				if(isFloat(s.c_str()))
				{
					sc = strtod(s.c_str(), NULL);
					if(0 <= sc && sc <= 5)
					{
						if(database.QueryScore("score", user->GetId().data(), name.data()))
						{
							double gp, mc, art, plot, opt;
							database.GetScore("score", user->GetId().data(), name.data(), &gp, &mc, &art, &plot, &opt);
							user->UpdateGp(gp);
							user->UpdateMc(mc);
							user->UpdateArt(art);;
							user->UpdatePlot(plot);
							user->UpdateOpt(opt);
							
							user->UpdateOpt(sc);
							database.UpdateScore("score", user->GetId().data(), name.data(), user->GetGp(), user->GetMc(), user->GetArt(), user->GetPlot(), user->GetOpt());
						}
						else
						{
							user->UpdateOpt(sc);
							database.AddScore("score", user->GetId().data(), name.data(), user->GetGp(), user->GetMc(), user->GetArt(), user->GetPlot(), user->GetOpt());
						}
						gs->UpdateGameRate("score", "��Ӫ", name);
						gs->AvgPlayer(name);
						cout << "���óɹ���\n";						
						system("pause");
						break;				
					}
					else
					{
						cout << "����ʧ�ܣ�\n";
					}
				}
				else
				{
					cout << "����ʧ�ܣ�\n";
				}				
			}while(1);
		}
		else if(choice == "7")
		{
			do
			{
				cout << "�������淨���֣�0~5�֣���";
				getline(cin, s);
				if(isFloat(s.c_str()))
				{
					sc = strtod(s.c_str(), NULL);
					if(0 <= sc && sc <= 5)
					{
						user->UpdateGp(sc);
						cout << "���óɹ���\n";
						break;					
					}
					else
					{
						cout << "����ʧ�ܣ�\n";
					}
				}
				else
				{
					cout << "����ʧ�ܣ�\n";
				}				
			}while(1);
			
			do
			{
				cout << "�������������֣�0~5�֣���";
				getline(cin, s);
				if(isFloat(s.c_str()))
				{
					sc = strtod(s.c_str(), NULL);
					if(0 <= sc && sc <= 5)
					{
						user->UpdateMc(sc);
						cout << "���óɹ���\n";	
						break;				
					}
					else
					{
						cout << "����ʧ�ܣ�\n";
					}
				}
				else
				{			
					cout << "����ʧ�ܣ�\n";
				}				
			}while(1);
			
			do
			{
				cout << "�������������֣�0~5�֣���";
				getline(cin, s);
				if(isFloat(s.c_str()))
				{
					sc = strtod(s.c_str(), NULL);
					if(0 <= sc && sc <= 5)
					{
						user->UpdateArt(sc);
						cout << "���óɹ���\n";
						break;					
					}
					else
					{
						cout << "����ʧ�ܣ�\n";
					}
				}
				else
				{
					cout << "����ʧ�ܣ�\n";
				}				
			}while(1);
			
			do
			{
				cout << "������������֣�0~5�֣���";
				getline(cin, s);
				if(isFloat(s.c_str()))
				{
					sc = strtod(s.c_str(), NULL);
					if(0 <= sc && sc <= 5)
					{
						user->UpdatePlot(sc);
						cout << "���óɹ���\n";	
						break;				
					}
					else
					{
						cout << "����ʧ�ܣ�\n";
					}
				}
				else
				{
					cout << "����ʧ�ܣ�\n";
				}				
			}while(1);
			
			do
			{
				cout << "��������Ӫ���֣�0~5�֣���";
				getline(cin, s);
				if(isFloat(s.c_str()))
				{
					sc = strtod(s.c_str(), NULL);
					if(0 <= sc && sc <= 5)
					{
						user->UpdateOpt(sc);
						cout << "���óɹ���\n";	
						break;				
					}
					else
					{
						cout << "����ʧ�ܣ�\n";
					}
				}
				else
				{
					cout << "����ʧ�ܣ�\n";
				}				
			}while(1);
			
			if(database.QueryScore("score", user->GetId().data(), name.data()))
			{
				database.UpdateScore("score", user->GetId().data(), name.data(), user->GetGp(), user->GetMc(), user->GetArt(), user->GetPlot(), user->GetOpt());
			}
			else
			{
				database.AddScore("score", user->GetId().data(), name.data(), user->GetGp(), user->GetMc(), user->GetArt(), user->GetPlot(), user->GetOpt());
			}
			gs->UpdateGameRate("score", "�淨", name);
			gs->UpdateGameRate("score", "����", name);
			gs->UpdateGameRate("score", "����", name);
			gs->UpdateGameRate("score", "����", name);
			gs->UpdateGameRate("score", "��Ӫ", name);
			gs->AvgPlayer(name);					
			system("pause");
		}
		else if(choice == "0")
		{
			return ;
		}
		else
		{
			cout << "��Ч���룡\n";
			system("pause");
		}
	}while(1);
}

void AddGameDirectory()
{
	string genre;
	DT* nowDT = dc->GetDT();
	DT* kDT = NULL;
	do
	{
		cin.sync();
		system("cls");	
		cout << "**************************************\n";
		cout << "*                                    *\n";
		cout << "*             ��ܰ��ʾ               *\n";
		cout << "*                                    *\n";
		cout << "*  1.�����Ӧ��ţ�������һĿ¼      *\n";
		cout << "*  2.����back����������һĿ¼        *\n";
		cout << "*  3.����0�Է���                     *\n";
		cout << "*                                    *\n";
		cout << "**************************************\n";
		cout << "--------------------------------------\n";
		cout << "\n";
		cout << "��Ϸ����Ŀ¼��\n";
		if(nowDT != NULL) dc->ShowCurrentDT(nowDT);
		cout << "\n";
		cout << "--------------------------------------\n";
		cout << "�������ڵ�ǰĿ¼��Ҫ���ӵ���Ϸ���ͣ�";
		getline(cin, genre);
		int k = -1; 
		if(isInt(genre.c_str())) k = FindNum(genre);
		if(genre == "0") 
		{
			return ;
		}
		else if(FindDirectory(genre))
		{
			cout << "��Ŀ¼�Ѵ��ڣ�\n";
			system("pause");
		}
		else if(genre == "back")
		{
			kDT = nowDT->fa;
			if(kDT != NULL) 
			{
				nowDT = kDT;
			}
			else
			{
				system("cls");
				cout << "��ǰ�Ѿ�������Ŀ¼����" << endl;
				system("pause"); 
			}
		}
		else if(k != -1)
		{
			if(kDT = dc->EnterNextDT(nowDT, k))
			{
//				cout << k << endl;
				nowDT = kDT;
			}
			else
			{
				system("cls");
				cout << "��ǰ�Ѿ�������Ŀ¼��!\n";
				system("pause");
			}

		}
		else
		{
			if(nowDT == NULL)
			{
				system("cls");
				cout << "��ǰ�Ѿ�������Ŀ¼����" << endl;
				system("pause"); 				
			}
			else
			{
				DT* sdt = new DT;
				sdt->genre = genre;
				sdt->fa = nowDT;
				nowDT->SDT.push_back(sdt);
				int n, j;
				n = j = 0;
				dc->UpdateLR(dc->GetDT(), &n, &j);
				dc->Numplus();				
			}
		}
		
	}while(1);
}

void DeleteGameDirectory()
{
	string genre;
	DT* nowDT = dc->GetDT();
	DT* kDT = NULL;
	do
	{
		cin.sync();
		system("cls");	
		cout << "**************************************\n";
		cout << "*                                    *\n";
		cout << "*             ��ܰ��ʾ               *\n";
		cout << "*                                    *\n";
		cout << "*  1.�����Ӧ��ţ�������һĿ¼      *\n";
		cout << "*  2.����back����������һĿ¼        *\n";
		cout << "*  3.����0�Է���                     *\n";
		cout << "*                                    *\n";
		cout << "**************************************\n";
		cout << "--------------------------------------\n";
		cout << "\n";
		cout << "��Ϸ����Ŀ¼��\n";
		dc->ShowCurrentDT(nowDT);
		cout << "\n";
		cout << "--------------------------------------\n";
		cout << "�������ڵ�ǰĿ¼��Ҫɾ������Ϸ���ͣ�";
		getline(cin, genre);
		int k = -1;
		if(isInt(genre.c_str())) k = FindNum(genre);
		if(genre == "0") 
		{
			return ;
		}
		else if(genre == "back")
		{
			kDT = nowDT->fa;
			if(kDT != NULL) 
			{
				nowDT = kDT;
			}
			else
			{
				system("cls");
				cout << "��ǰ�Ѿ�������Ŀ¼����" << endl;
				system("pause"); 
			}
		}
		else if(k != -1)
		{
			if((kDT = dc->EnterNextDT(nowDT, k)) != NULL)
			{
				if(dc->ShowCurrentDT(kDT)) nowDT = kDT;
				else 
				{
					system("cls");
					cout << "��ǰ�Ѿ�������Ŀ¼��!\n";
					system("pause");
				}	
			}
			else
			{
				system("pause");
			}

		}
		else
		{
			DT* pt = dc->FindTheDT(nowDT, genre);
			if(pt != NULL)
			{
				list<DT*>::iterator it = nowDT->SDT.begin();
				for( ; it != nowDT->SDT.end() ; it++)
				{
					if(pt == (*it))
					{
						nowDT->SDT.erase(it);
						break;
					}
				}
				int n, j;
				n = j = 0;
				dc->UpdateLR(dc->GetDT(), &n, &j);
				dc->NumSub();
			}
			else
			{
				cout << "�Ҳ�����Ҫɾ������Ϸ���ͣ�\n";
				system("pause"); 
			}
		}
		
	}while(1);	
}

void UpdateGameDirectory()
{
	string genre;
	DT* nowDT = dc->GetDT();
	DT* kDT = NULL;
	do
	{
		cin.sync();
		system("cls");	
		cout << "**************************************\n";
		cout << "*                                    *\n";
		cout << "*             ��ܰ��ʾ               *\n";
		cout << "*                                    *\n";
		cout << "*  1.�����Ӧ��ţ�������һĿ¼      *\n";
		cout << "*  2.����back����������һĿ¼        *\n";
		cout << "*  3.����0�Է���                     *\n";
		cout << "*                                    *\n";
		cout << "**************************************\n";
		cout << "--------------------------------------\n";
		cout << "\n";
		cout << "��Ϸ����Ŀ¼��\n";
		dc->ShowCurrentDT(nowDT);
		cout << "\n";
		cout << "--------------------------------------\n";
		cout << "�������ڵ�ǰĿ¼��Ҫ�޸ĵ���Ϸ���ͣ�";
		getline(cin, genre);
		int k = -1;
		if(isInt(genre.c_str())) k = FindNum(genre);
		if(genre == "0") 
		{
			return ;
		}
		else if(genre == "back")
		{
			kDT = nowDT->fa;
			if(kDT != NULL) 
			{
				nowDT = kDT;
			}
			else
			{
				system("cls");
				cout << "��ǰ�Ѿ�������Ŀ¼����" << endl;
				system("pause"); 
			}
		}
		else if(k != -1)
		{
			if((kDT = dc->EnterNextDT(nowDT, k)) != NULL)
			{
				if(dc->ShowCurrentDT(kDT)) nowDT = kDT;
				else 
				{
					system("cls");
					cout << "��ǰ�Ѿ�������Ŀ¼��!\n";
					system("pause");
				}	
			}
			else
			{
				system("pause");
			}

		}
		else
		{
			DT* pt = dc->FindTheDT(nowDT, genre);	
			if(pt != NULL)
			{
				do
				{
					cout << "��������Ҫ���ĺ����Ϸ�������ƣ�";
					getline(cin, genre);
					if(FindDirectory(genre)) cout << "��Ŀ¼�Ѵ��ڣ�\n";
					else
					{
						pt->genre = genre;
						break;
					}
	
				}while(1);

			}
			else
			{
				cout << "�Ҳ�����Ҫ�޸ĵ���Ϸ���ͣ�\n";
				system("pause"); 
			}
		}
		
	}while(1);	
}

bool FindDirectory(string genre)
{
	if(dc->FindDirectory(genre)) return true;
	return false;
}
